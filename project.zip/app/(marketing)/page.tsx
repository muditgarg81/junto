import React from 'react';
import { getCurrentUser } from '@/lib/auth';
import { query } from '@/lib/db';
import WelcomeClient from './WelcomeClient';
import YourTripsClient from './YourTripsClient';

export default async function HomePage() {
  const user = await getCurrentUser();

  if (!user) {
    return <WelcomeClient user={null} />;
  }

  // Fetch user's trips from database
  const tripsRes = await query(`
    SELECT t.*, 
      ('organizer' = ANY(m_user.roles)) AS is_creator,
      (
        SELECT o.payload
        FROM decisions d
        JOIN options o ON d.resolved_option_id = o.id
        WHERE d.trip_id = t.id AND d.type = 'dates' AND d.status = 'locked'
        LIMIT 1
      ) AS dates_payload,
      (
        SELECT json_agg(json_build_object('name', COALESCE(u_m.name, m.name), 'photo_url', u_m.photo_url))
        FROM members m
        LEFT JOIN users u_m ON m.user_id = u_m.id OR m.auth_id = u_m.auth_id
        WHERE m.trip_id = t.id AND m.status = 'confirmed'
      ) AS members
    FROM trips t
    JOIN members m_user ON t.id = m_user.trip_id
    WHERE m_user.user_id = $1 OR m_user.auth_id = $2
    ORDER BY t.created_at DESC
  `, [user.id, user.auth_id]);

  const dbTrips = tripsRes.rows;

  return (
    <YourTripsClient 
      user={user}
      dbTrips={dbTrips}
    />
  );
}
